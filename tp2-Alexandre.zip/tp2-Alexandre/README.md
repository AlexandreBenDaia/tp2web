# TP2

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```

### Lint-Fix with [ESLint](https://eslint.org/)

```sh
npm run fix
```
