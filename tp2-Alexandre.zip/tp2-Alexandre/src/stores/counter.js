import { createStore } from "vuex";

const store = createStore({
  state() {
    return {
      token: "",
      history: [],
    };
  },
  mutations: {
    setToken(state, newValue) {
      state.token = newValue;
    },
    setHistory(state, newValue) {
      state.history = newValue;
    },
  },
  actions: {
    storeToken({ commit }, newValue) {
      commit("setToken", newValue);
    },
    storeHistory({ commit }, newValue) {
      commit("setHistory", newValue);
    },
  },
  getters: {
    getToken(state) {
      return state.token;
    },
    getHistory(state) {
      return state.history;
    },
  },
});

export default store;
