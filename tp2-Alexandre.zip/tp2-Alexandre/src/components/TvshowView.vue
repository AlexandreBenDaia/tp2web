<template>
  <div class="column is-3-desktop is-4-tablet is-full-mobile">
    <router-link
      v-bind:to="{ name: 'detail', params: { tvshowId: tvshow.tvshowId } }"
    >
      <div class="card large">
        <div class="card-image">
          <figure class="image is-2by3">
            <img v-bind:src="tvshow.imgURL" v-bind:alt="tvshow.title" />
          </figure>
        </div>
        <div class="card-content">
          <div class="content has-text-centered">
            <p class="title is-3 has-text-centered" style="color: black">
              {{ tvshow.title }}
            </p>
            <div class="mb-0">
              <span class="has-text-weight-bold">studio: </span>
              <span>{{ tvshow.studio.name }}</span>
            </div>
            <div class="mb-0">
              <span class="has-text-weight-bold">Genres: </span>
              <span>{{ tvshow.genres.map((e) => e.name).join(", ") }}</span>
            </div>
          </div>
        </div>
      </div>
    </router-link>
  </div>
</template>

<script>
export default {
  name: "TvshowView",
  props: {
    tvshow: Object,
  },
};
</script>
