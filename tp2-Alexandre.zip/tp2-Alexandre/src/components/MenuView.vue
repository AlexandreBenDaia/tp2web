<template>
  <nav class="navbar is-link" role="navigation" aria-label="main navigation">
    <div class="navbar-menu">
      <div class="navbar-start">
        <router-link class="navbar-item" :to="{ name: 'home' }">
          TP2
        </router-link>
      </div>

      <div class="navbar-end">
        <router-link v-if="!token" class="navbar-item" :to="{ name: 'signup' }">
          Sign Up
        </router-link>
        <router-link v-if="!token" class="navbar-item" :to="{ name: 'login' }">
          Login
        </router-link>
        <router-link v-if="token" class="navbar-item" :to="{ name: 'home' }">
          Home
        </router-link>
        <router-link v-if="token" class="navbar-item" :to="{ name: 'history' }">
          History
        </router-link>
        <router-link v-if="token" class="navbar-item" :to="{ name: 'profile' }">
          Profile
        </router-link>
        <a v-if="token" @click="logout" class="navbar-item">
          Logout
        </a>
        <router-link class="navbar-item" :to="{ name: 'about' }">
          About
        </router-link>
      </div>
    </div>
  </nav>
</template>

<script>
import { computed } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";

export default {
  name: "MenuView",
  setup() {
    const store = useStore();
    const router = useRouter();
    const token = computed(() => store.state.token);

    const logout = () => {
      store.dispatch("storeToken", "");
      sessionStorage.removeItem("token");
      router.push("/");
    };

    return {
      token,
      logout,
    };
  },
};
</script>
