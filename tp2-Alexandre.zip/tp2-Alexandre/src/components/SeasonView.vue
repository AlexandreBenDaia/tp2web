      <template>
  <router-link
    v-bind:to="{ name: 'season', params: { seasonId: saison.seasonId } }"
  >
    <div class="card">
      <div class="card-image">
        <figure class="image is-3by4">
          <img v-bind:src="saison.imgURL" v-bind:alt="saison.name" />
        </figure>
      </div>
      <div class="card-content">
        <div class="content has-text-centered">
          <div class="has-text-weight-bold">Season{{ saison.number }}</div>
          <div>{{ saison.episodeCount }}episodes</div>
        </div>
      </div>
    </div>
  </router-link>
</template>

<script>
export default {
  name: "SaisonView",
  props: {
    saison: Object,
  },
};
</script>
