<template>
  <div class="column is-3-desktop is-4-tablet is-full-mobile">
    <router-link
      v-bind:to="{
        name: 'detailEpisode',
        params: { episodeId: episode.episodeId },
      }"
    >
      <div v-if="this.$store.state.token != ''">
        <div style="opacity: 0.5" class="card">
          <div class="card-image">
            <figure class="image is-16by9">
              <img v-bind:src="episode.imgURL" v-bind:alt="episode.name" />
            </figure>
          </div>
          <div class="card-content">
            <div class="content has-text-centered">
              <p class="title is-4 mb-0">
                <strong>{{ episode.title }}</strong>
              </p>
              <p>{{ episode.number }}</p>
            </div>
          </div>
        </div>
      </div>
      <div v-else>
        <div class="card">
          <div class="card-image">
            <figure class="image is-16by9">
              <img v-bind:src="episode.imgURL" v-bind:alt="episode.name" />
            </figure>
          </div>
          <div class="card-content">
            <div class="content has-text-centered">
              <p class="title is-4 mb-0">
                <strong>{{ episode.title }}</strong>
              </p>
              <p>{{ episode.number }}</p>
            </div>
          </div>
        </div>
      </div>
    </router-link>
  </div>
</template>

<script>
export default {
  name: "SeasonView",
  props: {
    episode: Object,
  },
};
</script>
