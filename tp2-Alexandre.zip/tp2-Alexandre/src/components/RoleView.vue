      <template>
  <div class="card">
    <div class="card-image">
      <figure class="image is-3by4">
        <img v-bind:src="role.imgURL" v-bind:alt="role.name" />
      </figure>
    </div>
    <div class="card-content">
      <div class="content has-text-centered">
        <div class="has-text-weight-bold">
          {{ role.name }}
        </div>
        <div>{{ role.character }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "RoleView",
  props: {
    role: Object,
  },
};
</script>
