<template>
  <div class="column is-4-desktop is-4-tablet is-full-mobile">
    <div class="card">
      <div class="card-image" disabled>
        <figure class="image is-16by9 is-transparent">
          <router-link :to="{ name: 'detailEpisode', params: { episodeId: p.episodeId } }">
            <img :src="p.imgURL" :alt="p.tvshowTitle" />
          </router-link>
        </figure>
      </div>
      <div class="card-content">
        <div class="content has-text-centered">
          <router-link class="has-text-info" :to="{ name: 'detail', params: { tvshowId: p.tvshowId } }">
            <strong>
              {{ p.tvshowTitle }}
            </strong>
          </router-link>
          <br />
          <router-link class="has-text-info" :to="{ name: 'season', params: { seasonId: p.seasonId } }">
            <strong>
              Season {{ p.seasonNumber }}
            </strong>
          </router-link>
          <br />
          <router-link class="has-text-info" :to="{ name: 'JouerEpisodeViewWithParam', params: { episodeId: p.episodeId } }">
            <strong>
              {{ p.episodeTitle }}
            </strong>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "HistoriqueItem",
  props: {
    p: {
      type: Object,
      required: true,
    },
  },
};
</script>
