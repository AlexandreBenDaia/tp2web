<template>
  <div>
    <div v-if="!isAuthenticated">
      <div
        class="has-text-centered"
        role="alert"
        style="white-space: pre"
        id="errorDiv"
      >
        <h1 class="title is-3">
          Vous devez être connecté pour accéder à cette page.
        </h1>
        <router-link class="has-text-info" :to="{ name: 'login' }"
          >Se connecter</router-link
        >
      </div>
    </div>
    <div v-else>
      <video
        v-if="episode"
        :src="episode.videoURL"
        width="1200"
        height="700"
        controls
      ></video>
    </div>
  </div>
</template>
  
  <script>
import { svrURL } from "@/constants";

export default {
  name: "JouerEpisodeView",
  data() {
    return {
      episode: null,
      isAuthenticated: false,
    };
  },
  mounted() {
    this.checkAuthentication();
    this.getEpisode();
  },
  methods: {
    checkAuthentication() {
      this.isAuthenticated = this.$store.state.token !== "";
    },
    async getEpisode() {
      if (!this.isAuthenticated) return;

      try {
        const bearerToken = `bearer ${this.$store.state.token}`;
        const response = await fetch(
          `${svrURL}/viewepisode?episodeId=${this.$route.query.episodeId}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              authorization: bearerToken,
            },
          }
        );

        if (response.ok) {
          this.episode = await response.json();
        } else {
          console.error("Failed to fetch episode details.");
        }
      } catch (error) {
        console.error(
          "An error occurred while fetching episode details:",
          error
        );
      }
    },
  },
};
</script>