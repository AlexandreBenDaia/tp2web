<template>
  <h1 class="title is-1 has-text-centered">Profile</h1>
  <div class="container">
    <nav class="navbar" role="navigation" aria-label="main navigation">
      <div class="navbar-brand">
        <div class="navbar-item">&nbsp;</div>
        <a
          role="button"
          class="navbar-burger"
          aria-label="menu"
          aria-expanded="false"
          data-target="navbarBasicExample"
        >
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
        </a>
      </div>
      <div class="navbar-menu"></div>
    </nav>
    <div v-if="Erreur !== ''">
      <div
        class="title is-3"
        tabindex="0"
        role="alert"
        style="white-space: pre"
        id="errorDiv"
        v-bind:style="{
          borderColor: 'red',
          borderWidth: '2px',
          borderStyle: 'solid',
        }"
      >
        {{ Erreur }}
      </div>
    </div>
    <div class="section">
      <div class="content">
        <div class="field">
          <label for="email" class="label">email</label>
          <div class="control has-icons-left">
            <input
              id="email"
              v-model="email"
              type="email"
              placeholder="e1234567@site.com"
              class="input"
              autocomplete="email"
              required
            />
            <span class="icon is-small is-left"
              ><i class="fa fa-envelope"></i
            ></span>
          </div>
        </div>
        <div class="field">
          <label for="email" class="label">username</label>
          <div class="control has-icons-left">
            <input
              id="username"
              v-model="username"
              type="input"
              placeholder="e1234567"
              class="input"
              autocomplete="email"
              required
            />
            <h6 class="has-text-primary">
              Le username doit contenire au moins 5 caractères et au maximum 20.
              Les caractèeres permis sont A-Z, a-z, 0-9 et le caractère souligné
            </h6>
            <span class="icon is-small is-left"
              ><i class="fa fa-envelope"></i
            ></span>
          </div>
        </div>
        <div class="field">
          <label for="password" class="label">Mot de passe</label>
          <div class="control has-icons-left">
            <input
              id="password"
              v-model="password"
              type="password"
              placeholder="*******"
              class="input"
              autocomplete="password"
              required
            />
            <h6 class="has-text-primary">
              Le mot de passe doit contenir au moins 6 caractères.
            </h6>
            <span class="icon is-small is-left"
              ><i class="fa fa-lock"></i
            ></span>
          </div>
        </div>
        <div class="field">
          <label for="password" class="label">Confirmer Mot de passe</label>
          <div class="control has-icons-left">
            <input
              id="Cpassword"
              v-model="Cpassword"
              type="password"
              placeholder="*******"
              class="input"
              autocomplete="password"
              required
            />
            <h6 class="has-text-primary">
              Le mot de passe et la confirmation doit être identique
            </h6>
            <span class="icon is-small is-left"
              ><i class="fa fa-lock"></i
            ></span>
          </div>
        </div>
        <p class="has-text-success has-text-centered" v-if="PUTenvoyé">
          *Modifications enregistrées avec succès
        </p>
        <div class="field">
          <div class="label"></div>
          <div class="control">
            <button
              id="connexion"
              v-on:click="update"
              class="button is-success"
            >
              update
            </button>
            <router-link class="button is-danger" v-bind:to="{ name: 'home' }">
              Annuler
            </router-link>
          </div>
          <div></div>
          <button class="button is-danger" v-on:click="suprimer">
            DELETE PROFILE
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { svrURL } from "@/constants";

export default {
  name: "ProfileView",
  data() {
    return {
      username: "",
      email: "",
      password: "",
      Cpassword: "",
      PUTenvoyé: false,
      // les validation
      Erreur: "",
    };
  },
  mounted() {
    if (this.$store.state.token === "") {
      this.$router.push("/");
    } else {
      this.getPersonne();
    }
  },
  methods: {
    async getPersonne() {
      const bearerToken = `bearer ${this.$store.state.token}`;
      const response = await fetch(`${svrURL}/user`, {
        method: "GET",
        headers: { authorization: bearerToken },
      });
      if (response.ok) {
        const user = await response.json();
        this.email = user.email;
        this.username = user.username;
      }
    },
    async suprimer() {
      if (window.confirm("Es-tu sur de vouloir suprimer cet utilisateur ?")) {
        const bearerToken = `bearer ${this.$store.state.token}`;
        const reponse = await fetch(`${svrURL}/user`, {
          method: "DELETE",
          headers: { authorization: bearerToken },
        });
        if (reponse.ok) {
          this.$store.dispatch("storeToken", "");
          this.$router.push("/");
        }
      }
    },
    async update() {
      let valide = true;
      if (this.username === "") {
        this.Erreur +=
          "Les caractères permis pour le username sont A-Z, a-z, 0-9 et la caractèere souligné.\n";
        valide = false;
      }
      if (
        this.username.length < 5 ||
        this.username.length > 20
        // || !this.username.includes([A-Za-z0-9]) || !this.username.includes('_')
      ) {
        this.Erreur +=
          "Le username doit contenir au moins 5 caractèeres et au maximum 20.\n";
        valide = false;
      }

      if (!this.email.includes("@") || !this.email.includes(".")) {
        this.Erreur += "Le courriel doit contenir le symbole @.\n";
        valide = false;
      }
      if (this.email === "") {
        this.Erreur += "Le courriel doit contenir plus de 4 caractères.\n";
        valide = false;
      }
      if (this.password === "") {
        this.Erreur += "";
        valide = false;
      }
      if (this.password.length < 6 || this.password.length > 30) {
        this.Erreur += "Le mot de passe doit contenir au moins 6 caractères.\n";
        valide = false;
      }
      if (this.Cpassword === "") {
        this.Erreur += "";
        valide = false;
      }
      if (this.Cpassword !== this.password) {
        this.Erreur +=
          "Le mot de passe et la confirmation doit être identique.\n";
        valide = false;
      }

      if (valide) {
        const connection = {
          username: this.username,
          email: this.email,
          password: this.password,
        };
        const bearerToken = `bearer ${this.$store.state.token}`;
        const response = await fetch(`${svrURL}/user`, {
          method: "POST",
          headers: {
            authorization: bearerToken,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(connection),
        });
        if (response.ok) {
          this.PUTenvoyé = true;
          setTimeout(() => {
            this.$router.push("/");
          }, 2000);
        } else {
          const d = await response.json();
          console.log(d);
        }
      }
    },
  },
};
</script>
<style scoped>
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

.has-text-centered {
  text-align: center;
}

.field {
  margin-bottom: 20px;
}

.has-icons-left {
  position: relative;
}

.icon.is-small.is-left {
  position: absolute;
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
}

.has-text-primary {
  color: #3273dc;
}

.help.is-danger {
  color: red;
}

.button.is-success {
  margin-right: 10px;
}

.button.is-danger {
  margin-right: 10px;
}

.button.is-danger:hover {
  background-color: #ff3860;
}

.has-text-success {
  color: green;
}
</style>
