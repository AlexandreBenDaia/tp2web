<template>
  <h1 class="title is-1 has-text-centered">Sign Up</h1>
  <div class="container">
    <div v-if="Erreur !== ''">
      <div
        class="title is-3"
        tabindex="0"
        role="alert"
        style="white-space: pre"
        id="errorDiv"
        :style="{
          borderColor: 'red',
          borderWidth: '2px',
          borderStyle: 'solid',
        }"
      >
        {{ Erreur }}
      </div>
    </div>
    <div class="section">
      <div class="content">
        <div class="field">
          <label for="email" class="label">Email</label>
          <div class="control has-icons-left">
            <input
              id="email"
              v-model="email"
              type="email"
              placeholder="e1234567@site.com"
              class="input"
              autocomplete="email"
              aria-required="true"
            />
            <span class="icon is-small is-left">
              <i class="fa fa-envelope"></i>
            </span>
          </div>
        </div>
        <div class="field">
          <label for="username" class="label">Username</label>
          <div class="control has-icons -left">
            <input
              id="username"
              v-model="username"
              type="input"
              placeholder="e1234567"
              class="input"
              autocomplete="username"
              aria-required="true"
              aria-describedby="username-help"
            />
            <h6 id="username-help" class="has-text-primary">
              The username must contain at least 5 characters and a maximum of
              20. Allowed characters are A-Z, a-z, 0-9, and underscore (_).
            </h6>
            <span class="icon is-small is-left">
              <i class="fas fa-user"></i>
            </span>
          </div>
        </div>
        <div class="field">
          <label for="password" class="label">Password</label>
          <div class="control has-icons-left">
            <input
              id="password"
              v-model="password"
              type="password"
              placeholder="*******"
              class="input"
              autocomplete="new-password"
              aria-required="true"
              aria-describedby="password-help"
            />
            <h6 id="password-help" class="has-text-primary">
              The password must contain at least 6 characters.
            </h6>
            <span class="icon is-small is-left">
              <i class="fa fa-lock"></i>
            </span>
          </div>
        </div>
        <div class="field">
          <label for="confirm-password" class="label">Confirm Password</label>
          <div class="control has-icons-left">
            <input
              id="confirm-password"
              v-model="Cpassword"
              type="password"
              placeholder="*******"
              class="input"
              autocomplete="new-password"
              aria-required="true"
            />
            <span class="icon is-small is-left">
              <i class="fa fa-lock"></i>
            </span>
          </div>
        </div>
        <p class="has-text-success has-text-centered" v-if="POSTenvoyé">
          *Person added successfully
        </p>
        <div class="field">
          <div class="label"></div>
          <div class="control">
            <button
              id="signup"
              @click="signup"
              class="button is-success"
              role="button"
              aria-label="Sign Up"
            >
              Sign Up
            </button>
            <router-link
              class="button is-danger"
              :to="{ name: 'home' }"
              role="button"
              aria-label="Cancel"
            >
              Cancel
            </router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import { ref } from "vue";
import { svrURL } from "@/constants";

export default {
  name: "SignUpView",
  setup() {
    const email = ref("");
    const username = ref("");
    const password = ref("");
    const Cpassword = ref("");
    const POSTenvoyé = ref(false);
    const Erreur = ref("");

    const validateForm = () => {
      Erreur.value = "";

      if (username.value === "") {
        Erreur.value += "Le nom d'utilisateur est obligatoire.\n";
        return false;
      }
      if (!/^[A-Za-z][A-Za-z0-9_]{4,19}$/.test(username.value)) {
        Erreur.value +=
          "Le nom d'utilisateur doit commencer par une lettre, contenir entre 5 et 20 caractères et ne peut contenir que des lettres majuscules, des lettres minuscules, des chiffres et le caractère souligné (_).\n";
        return false;
      }

      if (!email.value.includes("@") || !email.value.includes(".")) {
        Erreur.value += "L'email doit contenir le caractère @.\n";
        return false;
      }
      if (
        email.value === "" ||
        email.value.length < 5 ||
        email.value.length > 50
      ) {
        Erreur.value += "L'email doit contenir entre 5 et 50 caractères.\n";
        return false;
      }
      if (password.value === "") {
        Erreur.value += "Le mot de passe est obligatoire.\n";
        return false;
      }
      if (password.value.length < 8 || password.value.length > 30) {
        Erreur.value +=
          "Le mot de passe doit contenir entre 8 et 30 caractères.\n";
        return false;
      }
      if (Cpassword.value === "") {
        Erreur.value += "La confirmation du mot de passe est obligatoire.\n";
        return false;
      }
      if (Cpassword.value !== password.value) {
        Erreur.value +=
          "Le mot de passe et la confirmation doivent correspondre.\n";
        return false;
      }

      return true;
    };

    const signup = async () => {
      if (!validateForm()) {
        return;
      }

      try {
        const body = {
          email: email.value,
          username: username.value,
          password: password.value,
        };

        const response = await fetch(`${svrURL}/auth/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });

        if (response.ok) {
          POSTenvoyé.value = true;
          setTimeout(() => {
            POSTenvoyé.value = false;
          }, 2000);
        } else {
          const data = await response.json();
          Erreur.value = data.message;
        }
      } catch (error) {
        console.log(error);
        Erreur.value = "Une erreur s'est produite lors de l'inscription.";
      }
    };

    return {
      email,
      username,
      password,
      Cpassword,
      POSTenvoyé,
      Erreur,
      signup,
    };
  },
};
</script>

