<template>
    <div>
      <h1 class="title is-1 has-text-centered">History</h1>
      <div class="columns is-multiline is-variable is-2-desktop is-1-tablet">
        <HistoriqueItem v-for="p in EpisodePagine" :key="p.episodeId" :p="p" class="column is-half-mobile is-one-third-tablet" />
      </div>
      <div class="columns is-mobile is-multiline">
        <div class="column is-2">
          <nav class="pagination" role="navigation" aria-label="arrow-pagination">
            <button
              @click="pagePrecedent"
              class="pagination-previous"
              @keydown="pagePrecedent"
            >
              Previous
            </button>
            <button
              @click="pageSuivant"
              class="pagination-next"
              @keydown="pageSuivant"
            >
              Next page
            </button>
            <ul class="pagination-list">
              <li v-for="d in nbPages" :key="d">
                <button
                  class="pagination-link"
                  @click="page(d)"
                  :class="{ 'is-current': d === pageCourante }"
                  @keydown="page(d)"
                >
                  {{ d }}
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </template>
  <script>
import { svrURL } from "@/constants";
import HistoriqueItem from "@/components/HistoriqueItem.vue";

export default {
  name: "HistoryView",
  components: { HistoriqueItem },
  data() {
    return {
      history: [],
      pageCourante: 1,
      taillePage: 6,
    };
  },
  computed: {
    EpisodePagine() {
      const x = (this.pageCourante - 1) * this.taillePage;
      const y = this.pageCourante * this.taillePage;
      return this.history.slice(x, y);
    },
    nbPages() {
      return Math.ceil(this.history.length / this.taillePage);
    },
  },
  mounted() {
    this.getHistory();
  },
  methods: {
    async getHistory() {
      const bearerToken = `bearer ${this.$store.state.token}`;
      const response = await fetch(`${svrURL}/user/history`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          authorization: bearerToken,
        },
      });
      if (response.ok) {
        this.history = await response.json();
      }
    },
    pageSuivant() {
      if (this.pageCourante < this.nbPages) {
        this.pageCourante += 1;
      }
    },
    pagePrecedent() {
      if (this.pageCourante > 1) {
        this.pageCourante -= 1;
      }
    },
    page(p) {
      this.pageCourante = p;
    },
  },
};
</script>