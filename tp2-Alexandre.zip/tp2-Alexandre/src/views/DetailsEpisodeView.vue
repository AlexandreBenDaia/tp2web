<template>
  <div>
    <div class="title is-1 has-text-centered">
      <span>{{ episode.tvshowTitle }}</span>
    </div>
    <h3 class="title is-1 has-text-centered">
      <span>{{ episode.seasonNumber }}-</span>
      <span>{{ episode.number }}-</span>
      <span>{{ episode.title }}</span>
    </h3>
    <p>{{ episode.runtime }} mins</p>
    <p>{{ episode.tvParentalGuideline }}</p>
    <p class="has-text-centered">{{ episode.plot }}</p>
    <div class="has-text-centered" style="padding-top: 50px">
      <router-link :to="`/viewepisode?episodeId=${episode.episodeId}`">
        <img :alt="episode.title" :src="episode.imgURL" />
        <img
          id="somelement"
          src="https://4d6tp2.sv55.cmaisonneuve.qc.ca/img/play.9fcb8068.png"
          alt="play"
          data-v-822c46ee=""
        />
      </router-link>
    </div>
    <div></div>
  </div>
</template>

  <script>
import { svrURL } from "@/constants";

export default {
  name: "DetailsEpisodeView",
  data() {
    return {
      episode: {},
    };
  },
  mounted() {
    this.getEpisode();
  },
  methods: {
    async getEpisode() {
      try {
        const response = await fetch(
          `${svrURL}/episode?episodeId=${this.$route.params.episodeId}`
        );
        if (response.ok) {
          this.episode = await response.json();
        } else {
          console.error("Failed to fetch episode details.");
        }
      } catch (error) {
        console.error(
          "An error occurred while fetching episode details:",
          error
        );
      }
    },
  },
};
</script>

  <style>
#somelement {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
}
</style>
