<template>
     <div class="section">
          <div class="columns is-centered">
        <div class="columns">
            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label for="titre" class="label">Title: </label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <p  role="search" class="control is-expanded">
                            <input
                                v-model="filtreTitre"
                                id="titre" class="input" type="text"
                                placeholder="name">
                        </p>
                    </div>
                </div>
            </div>

            <div class="field is-horizontal" style="padding-left:20px">
                <div class="field-label is-normal">
                    <label class="label" for="studios">Studio: </label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="control" style="min-width: 200px">
                            <div class="select is-fullwidth">
                                <select role="search" id="studios"
                                        v-model="filtreStudio">
                                    <option></option>
                                    <option
                                        v-for="a in studios"
                                        v-bind:key="a.studioId">{{ a.name}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <div class="panel">
         <p class= "panel-heading">
             Genres
         </p>
         <div class="panel-block">
                 <div class=" columns  is-mobile is-multiline ">
                    <label  role="search" class="column is-2 "
                 v-for="x in genre"
                 v-bind:key="x.genreId">

        <label class="checkbox label">
            <input type="checkbox" v-bind:value="x.genreId" v-model="filtreGenre">
            {{ x.name}}
                </label>
                </label>
        </div>
        </div>
        </div>
            </div>
        <div class="block">
        <div class=" columns is-multiline is-mobile">

     <TvshowView
                v-for="tvshow in tvshowFiltresPagine"
                 v-bind:key="tvshow.tvshowId"
                 v-bind:tvshow="tvshow" />

        </div>
        </div>
<div class= "colums is-mobile is-multiline">
    <div class colums is-2>
    <nav class="pagination" role="navigation" aria-label="arrow-pagination" >
  <button v-on:click = "pagePrecedent" class="pagination-previous" v-on:keydown="pagePrecedent" >
      Previous</button>
  <button v-on:click = "pageSuivant" class="pagination-next"
   v-on:keydown="pageSuivant">Next page</button>
  <ul class="pagination-list">
    <li v-for="d in nbPages" v-bind:key="d" >
      <button class="pagination-link" v-on:click ="page(d)"
       v-bind:class="{'is-current': d == pageCourante }"
      v-on:keydown="page(d)">{{d}}</button>
    </li>
  </ul>
</nav>
</div>
</div>
</template>

<script>
import { svrURL } from "@/constants";
import TvshowView from "@/components/TvshowView.vue";

export default {
  name: "HomeView",
  components: { TvshowView },
  data() {
    return {
      tvshows: [],
      studios: [],
      genre: [],
      filtreTitre: "",
      filtreStudio: "",
      filtreGenre: [],
      pageCourante: 1,
      taillePage: 8,
    };
  },
  computed: {
    tvshowFiltres() {
      let tvshowFiltres = this.tvshows;
      if (this.filtreTitre !== "") {
        tvshowFiltres = tvshowFiltres.filter((p) =>
          p.title.toLowerCase().includes(this.filtreTitre.toLowerCase())
        );
      }
      if (this.filtreStudio !== "") {
        tvshowFiltres = tvshowFiltres.filter(
          (p) => p.studio.name === this.filtreStudio
        );
      }
      if (this.filtreGenre.length === 1) {
        tvshowFiltres = tvshowFiltres.filter((p) =>
          this.filtreGenre.every((g) =>
            p.genres.map((x) => x.genreId).includes(g)
          )
        );
      }
      return tvshowFiltres;
    },
    tvshowFiltresPagine() {
      const x = (this.pageCourante - 1) * this.taillePage;
      const y = this.pageCourante * this.taillePage;
      console.log(x, y);
      return this.tvshowFiltres.slice(x, y);
    },
    nbPages() {
      return Math.ceil(this.tvshowFiltres.length / this.taillePage);
    },
  },
  mounted() {
    this.getStudio();
    this.getTvshows();
    this.getGenre();
  },
  methods: {
    pageSuivant() {
      if (this.pageCourante < this.nbPages) {
        this.pageCourante += 1;
      }
    },
    pagePrecedent() {
      if (this.pageCourante > 1) {
        this.pageCourante -= 1;
      }
    },
    page(p) {
      console.log(p);
      this.pageCourante = p;
    },
    async getStudio() {
      const rep = await fetch(`${svrURL}/studios`);
      if (rep.ok) {
        this.studios = await rep.json();
      }
    },
    async getTvshows() {
      const rep = await fetch(`${svrURL}/tvshows`);
      if (rep.ok) {
        this.tvshows = await rep.json();
      }
    },
    async getGenre() {
      const rep = await fetch(`${svrURL}/genres`);
      if (rep.ok) {
        this.genre = await rep.json();
      }
    },
  },
};
</script>







