<template>
  <div class="cute-about" :style="{ backgroundColor: randomColor }">
    <h1 class="title is-1 has-text-centered fancy-text">
      Bonne fin de session! <span class="emoji">❤️</span>
    </h1>
    <p class="percentage fancy-text">100%</p>
    <div class="cool-feature">
      <button @click="generateRandomColor" class="styled-button">
        Generate Random Color
      </button>
      <div class="color-box" :style="{ backgroundColor: randomColor }"></div>
    </div>
    <p class="credit">Développé par Alexandre Ben Daia</p>
  </div>
</template>
  
  <script>
export default {
  name: "CuteAbout",
  data() {
    return {
      randomColor: "",
    };
  },
  mounted() {
    this.generateRandomColor();
  },
  methods: {
    generateRandomColor() {
      const randomHexColor =
        "#" + Math.floor(Math.random() * 16777215).toString(16);
      this.randomColor = randomHexColor;
      document.body.style.backgroundColor = randomHexColor; // Set page background color
    },
  },
  beforeUnmount() {
    document.body.style.backgroundColor = ""; // Reset page background color when component is unmounted
  },
};
</script>
  
  <style>
/* Styles updated by Alexandre Ben Daia */

@import url("https://fonts.googleapis.com/css2?family=Pacifico&display=swap");

.cute-about {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  font-family: "Pacifico", cursive;
}

.fancy-text {
  font-size: 3rem;
  font-weight: bold;
  color: #ff69b4;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.emoji {
  font-size: 2rem;
}

.percentage {
  font-size: 4rem;
  font-weight: bold;
  color: #ff69b4;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.cool-feature {
  margin-top: 2rem;
  display: flex;
  align-items: center;
}

.styled-button {
  padding: 1rem 2rem;
  font-size: 1.4rem;
  font-weight: bold;
  color: #ffffff;
  background-color: #ff69b4;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.3);
  transition: background-color 0.3s ease;
}

.styled-button:hover {
  background-color: #ff519a;
}

.color-box {
  width: 100px;
  height: 100px;
  border-radius: 4px;
}

.credit {
  margin-top: 1rem;
  font-size: 1rem;
  color: #888888;
}
</style>
  