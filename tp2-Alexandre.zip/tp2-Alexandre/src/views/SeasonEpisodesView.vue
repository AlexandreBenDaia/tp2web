<template>
  <div v-if="this.episodes !== null">
    <div class="title is-1 has-text-centered">
      <span>{{ episodes.tvshowTitle }}</span>
    </div>
    <div class="title is-1 has-text-centered">
      <span>{{ episodes.seasonNumber }}</span>
    </div>
    <div class="columns is-mobile is-multiline scrolling-wrapper-flexbox">
      <SaisonEpisodeView
        v-for="episode in EpisodePagine"
        v-bind:key="episode.episodeId"
        v-bind:episode="episode"
      />
    </div>
    <div class="colums is-mobile is-multiline">
      <div class colums is-2>
        <nav class="pagination" role="navigation" aria-label="arrow-pagination">
          <button
            v-on:click="pagePrecedent"
            class="pagination-previous"
            v-on:keydown="pagePrecedent"
          >
            Previous
          </button>
          <button
            v-on:click="pageSuivant"
            class="pagination-next"
            v-on:keydown="pageSuivant"
          >
            Next page
          </button>
          <ul class="pagination-list">
            <li v-for="d in nbPages" v-bind:key="d">
              <button
                class="pagination-link"
                v-on:click="page(d)"
                v-bind:class="{ 'is-current': d == pageCourante }"
                v-on:keydown="page(d)"
              >
                {{ d }}
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</template>

<script>
import { svrURL } from "@/constants";
import SaisonEpisodeView from "@/components/SaisonEpisodeView.vue";

export default {
  name: "SeasonEpisodesView",
  components: { SaisonEpisodeView },
  data() {
    return {
      episodes: null,
      pageCourante: 1,
      taillePage: 8,
    };
  },
  computed: {
    EpisodePagine() {
      const x = (this.pageCourante - 1) * this.taillePage;
      const y = this.pageCourante * this.taillePage;
      console.log(x, y);
      return this.episodes.episodes.slice(x, y);
    },
    nbPages() {
      return Math.ceil(this.episodes.episodes.length / this.taillePage);
    },
  },

  mounted() {
    this.getEpisodes();
  },
  methods: {
    pageSuivant() {
      if (this.pageCourante < this.nbPages) {
        this.pageCourante += 1;
      }
    },
    pagePrecedent() {
      if (this.pageCourante > 1) {
        this.pageCourante -= 1;
      }
    },
    page(p) {
      console.log(p);
      this.pageCourante = p;
    },
    async getEpisodes() {
      const rep = await fetch(
        `${svrURL}/episodes?seasonId=${this.$route.params.seasonId}`
      );
      if (rep.ok) {
        this.episodes = await rep.json();
      }
    },
  },
};
</script>
