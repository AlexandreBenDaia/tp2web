<template>
  <div v-if="this.tvshow !== null">
    <div class="columns is-multiline">
      <div class="column is-5">
        <img v-bind:alt="tvshow.title" v-bind:src="tvshow.imgURL" />
      </div>
      <div class="column is-7">
        <div class="columns is-multiline">
          <div class="column is-8">
            <div class="title is-1">
              <h2>{{ tvshow.title }}</h2>
            </div>
          </div>
          <div class="column is-12 has-text-weight-bold">
            <p>{{ tvshow.year }}</p>
          </div>
          <div class="column is-2 has-text-weight-bold">
            <p>  {{ tvshow.episodeCount }} episodes</p>
          </div>
          <div class="column is-2 has-text-weight-bold">
            <p>{{ tvshow.tvParentalGuideline }}</p>
          </div>
          <div class="column is-8 has-text-weight-bold">
            <p>{{ tvshow.genres.map((e) => e.name).join(", ") }}</p>
          </div>
        </div>
        <div class="column is-2 has-text-weight-bold">
          <p>Studio            {{ tvshow.studio.name }}</p>
        </div>
        <div class="column is-12 has-text-justified has-text-weight-bold">
          <span>{{ tvshow.plot }}</span>
        </div>
      </div>
    </div>
    <div
      class="columns is-mobile scrolling-wrapper-flexbox"
      style="display: flex; flex-wrap: nowrap; overflow-x: auto"
    >
      <RoleView v-for="role in tvshow.roles" class="column is-2"
      v-bind:key="role.roleId"
      v-bind:role="role"/>
    </div>
        <div
      class="columns is-mobile scrolling-wrapper-flexbox"
      style="display: flex; flex-wrap: nowrap; overflow-x: auto "
    >
    <SeasonView
    v-for="saison in tvshow.seasons" class="column is-3"
    v-bind:key="saison.seasonId"
    v-bind:saison="saison"/>

    </div>
     <!-- Audio Player -->
     <audio ref="audioPlayer" :src="tvshow.audioURL" controls autoplay></audio>
    </div>
</template>

<script>
import { svrURL } from "@/constants";
import SeasonView from "@/components/SeasonView.vue";
import RoleView from "@/components/RoleView.vue";

export default {
    name: "DetailView",
    components: { SeasonView, RoleView },
    data() {
        return {
            tvshow: null,
        };
    },

    mounted() {
        this.getTvshows();
    },
    methods: {
        async getTvshows() {
            const rep = await fetch(
                `${svrURL}/tvshow?tvshowId=${this.$route.params.tvshowId}`,
            );
            if (rep.ok) {
                this.tvshow = await rep.json();
            }
        },

    },
};
</script>
<style scoped>
</style>
