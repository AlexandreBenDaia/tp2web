<template>
  <div>
    <h1 class="title is-1 has-text-centered">Login</h1>
    <div class="container">
      <div v-if="error !== ''">
        <div
          class="title is-3"
          tabindex="0"
          role="alert"
          style="white-space: pre"
          :style="{ borderColor: 'red', borderWidth: '2px', borderStyle: 'solid' }"
        >
          {{ error }}
        </div>
      </div>
      <div class="section">
        <div class="content">
          <div class="field">
            <label for="username" class="label">Username</label>
            <div class="control has-icons-left">
              <input
                id="username"
                v-model="username"
                type="text"
                class="input"
                placeholder="e1234567"
                required
              />
              <span class="icon is-small is-left">
                <i class="fa fa-user"></i>
              </span>
            </div>
          </div>
          <div class="field">
            <label for="password" class="label">Password</label>
            <div class="control has-icons-left">
              <input
                id="password"
                v-model="password"
                type="password"
                class="input"
                placeholder="*******"
                required
              />
              <span class="icon is-small is-left">
                <i class="fa fa-lock"></i>
              </span>
            </div>
          </div>
          <div class="field">
            <div class="control">
              <button
                @click="login"
                class="button is-success"
                role="button"
                aria-label="Login"
              >
                Login
              </button>
              <router-link
                class="button is-danger"
                :to="{ name: 'home' }"
                role="button"
                aria-label="Cancel"
              >
                Cancel
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import { ref, getCurrentInstance } from "vue";
import { svrURL } from "@/constants";

export default {
  name: "LoginView",
  setup() {
    const instance = getCurrentInstance();
    const username = ref("");
    const password = ref("");
    const error = ref("");
    const store = instance.proxy.$store;

    const login = async () => {
      let isValid = true;

      if (username.value === "") {
        error.value += "Please enter a username.\n";
        isValid = false;
      }
      if (password.value === "") {
        error.value += "Please enter a password.\n";
        isValid = false;
      }

      if (isValid) {
        const credentials = {
          username: username.value,
          password: password.value,
        };

        try {
          const response = await fetch(`${svrURL}/auth/token`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(credentials),
          });

          if (response.ok) {
            const data = await response.json();
            console.log("Login successful. Token:", data.token);
            store.dispatch("storeToken", data.token);
            localStorage.setItem("token", data.token);
            instance.proxy.$router.push({ name: "home" });
          } else {
            const errorData = await response.json();
            error.value = errorData.message;
          }
        } catch (error) {
          console.log(error);
          error.value = "An error occurred during login.";
        }
      }
    };

    return {
      username,
      password,
      error,
      login,
    };
  },
};
</script>


