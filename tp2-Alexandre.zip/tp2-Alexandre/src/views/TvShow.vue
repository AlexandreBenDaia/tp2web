<template>
  <div class="column is-one-quarter-desktop is-one-third-tablet is-half-mobile">
    <div class="card">
      <div class="card-image">
        <figure class="image is-4by3">
          <img :src="show.imgURL" :alt="show.title" />
        </figure>
      </div>
      <div class="card-content">
        <p class="title is-4">{{ show.title }}</p>
        <p class="subtitle is-6">
          {{ show.genres.map((genre) => genre.name).join(", ") }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TvShow",
  props: {
    show: {
      type: Object,
      required: true,
    },
  },
};
</script>

