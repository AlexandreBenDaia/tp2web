import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./stores/counter";

// Vérifier s'il existe un jeton dans le stockage local
const token = localStorage.getItem("token");

if (token) {
  // Restaurer le jeton dans le gestionnaire d'état
  store.dispatch("storeToken", token);
}

createApp(App)
  .use(store)
  .use(router)
  .mount("#app");
