const svrURL = "https://tvshowdbapi.herokuapp.com";

export { svrURL };
