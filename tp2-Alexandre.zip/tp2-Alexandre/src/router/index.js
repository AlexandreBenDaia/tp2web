import { createRouter, createWebHistory } from "vue-router";
import HomeView from "@/views/HomeView.vue";
import DetailView from "@/views/DetailView.vue";
import SeasonEpisodesView from "@/views/SeasonEpisodesView.vue";
import DetailsEpisodeView from "@/views/DetailsEpisodeView.vue";
import LoginView from "@/views/LoginView.vue";
import SignUpView from "@/views/SignUpView.vue";
import AboutView from "@/views/AboutView.vue";
import ProfileView from "@/views/ProfileView.vue";
import HistoryView from "@/views/HistoryView.vue";
import JouerEpisodeView from "@/views/JouerEpisodeView.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
  },
  {
    path: "/detail/:tvshowId",
    name: "detail",
    component: DetailView,
  },
  {
    path: "/season/:seasonId",
    name: "season",
    component: SeasonEpisodesView,
  },
  {
    path: "/episodedetails/:episodeId",
    name: "detailEpisode",
    component: DetailsEpisodeView,
  },
  {
    path: "/login",
    name: "login",
    component: LoginView,
  },
  {
    path: "/signup",
    name: "signup",
    component: SignUpView,
  },
  {
    path: "/about",
    name: "about",
    component: AboutView,
  },
  {
    path: "/profile",
    name: "profile",
    component: ProfileView,
  },
  {
    path: "/history",
    name: "history",
    component: HistoryView,
  },
  {
    path: "/viewepisode/:episodeId",
    name: "JouerEpisodeViewWithParam",
    component: JouerEpisodeView,
    props: true,
  },
  {
    path: "/viewepisode",
    name: "JouerEpisodeViewWithQuery",
    component: JouerEpisodeView,
    props: (route) => ({ episodeId: parseInt(route.query.episodeId) }),
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
