<template>
  <div>
    <MenuView />
    <div class="container" role="main">
      <router-view />
    </div>
  </div>
</template>

<script>
import MenuView from "@/components/MenuView.vue";

export default {
  components: {
    MenuView,
  },
  mounted() {
    const token = sessionStorage.getItem("token");
    if (token) {
      this.$store.dispatch("storeToken", token);
    }
  },
};
</script>

<style>
@import "font-awesome/css/font-awesome.min.css";
@import "bulma/css/bulma.min.css";
</style>
