function checkNomInput(str) {
    return /^[a-zA-Z\- ÄäÖöÉéÈèÜüÊêÛûÎî]+$/.test(str);
}
function checkPrenomInput(str) {
    return /^[a-zA-ZÄäÖöÉéÈèÜüÊêÛûÎî]+$/.test(str);
}

export {
    checkNomInput,
    checkPrenomInput,
};
